# HAKUNA MATATA

THIS SOFTWARE UNLICENSE IS PROVIDED WITH ONE WARNING:

- IF YOU BUILD A CYBERNETIC VELOCIRAPTOR, DON'T MAKE IT TOO SMART.

# TERMS AND CONDITIONS

## 0. Definitions.

"UNLICENSE" refers to an ancient greek word that is best defined in one of the most famous quotes from the magnificent neo-confucianist Spanish philosopher Mariano Rajoy:

> Worse is better for all and the worse for all, the better; better for me, his political gain.