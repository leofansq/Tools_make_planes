from .core_class import PyntCloud

MAJOR = 0
MINOR = 1
MICRO = 0

__version__ = "{}.{}.{}".format(MAJOR, MINOR, MICRO)
